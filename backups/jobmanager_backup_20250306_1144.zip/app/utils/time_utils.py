# app/utils/time_utils.py
from datetime import datetime
import logging

logger = logging.getLogger('jobmanager')

def get_current_time():
    """
    Get the current system time and return it in ISO format.
    This centralizes all time functions to ensure consistency.
    """
    # Get the raw current local time from the system
    now = datetime.now()
    
    # Format it consistently with ISO format
    formatted_time = now.isoformat(timespec='seconds')
    logger.debug(f"Current system time: {formatted_time}")
    return formatted_time

def parse_datetime(datetime_str):
    """
    Parse a datetime string into a datetime object.
    """
    try:
        return datetime.fromisoformat(datetime_str)
    except ValueError:
        logger.warning(f"Failed to parse datetime: {datetime_str}")
        return datetime.now()

def format_datetime_display(datetime_str):
    """
    Format a datetime string for display.
    """
    if not datetime_str:
        return ""
    
    dt = parse_datetime(datetime_str)
    return dt.strftime("%Y-%m-%d %H:%M:%S")