# app/routes/report_routes.py
from flask import Blueprint, render_template, request, redirect, url_for
from ..db import with_db
from datetime import datetime, timedelta, date
import sqlite3
import logging

bp = Blueprint('report', __name__)
logger = logging.getLogger('jobmanager')

@bp.route('/weekly_summary')
@with_db
def weekly_summary(db):
    """Generate a weekly summary report of all jobs worked on"""
    try:
        # Get current week or selected week
        selected_week = request.args.get('week', None)
        show_all = request.args.get('show_all', 'false').lower() == 'true'
        
        # If no week is selected, use current week
        if not selected_week:
            today = date.today()
            # Get ISO week
            year, week_num, _ = today.isocalendar()
            selected_week = f"{year}-W{week_num:02d}"
            
        # Get all available weeks for the dropdown
        try:
            available_weeks = db.execute('''
                WITH weeks AS (
                    SELECT 
                        strftime('%Y', datetime(start_time, 'unixepoch')) || '-W' || 
                        CAST(strftime('%W', datetime(start_time, 'unixepoch')) AS INTEGER) + 1 AS week_str,
                        MIN(start_time) AS first_entry
                    FROM time_entry
                    GROUP BY week_str
                    ORDER BY first_entry DESC
                )
                SELECT week_str FROM weeks
            ''').fetchall()
        except Exception as e:
            logger.error(f"Error fetching available weeks: {str(e)}")
            available_weeks = []
        
        # For current week, ensure it appears in available weeks even if no entries yet
        today = date.today()
        year, week_num, _ = today.isocalendar()
        current_week = f"{year}-W{week_num:02d}"
        
        # Check if current week is in available weeks
        current_week_exists = False
        for week in available_weeks:
            if isinstance(week, dict) and 'week_str' in week and week['week_str'] == current_week:
                current_week_exists = True
                break
                
        # Add current week if not in list
        if not current_week_exists:
            # Create a dummy entry for the dropdown
            available_weeks = [{'week_str': current_week}] + list(available_weeks)
        
        # Get all weeks data if show_all is true
        if show_all:
            try:
                # Get summary data for all weeks
                weekly_data = db.execute('''
                    WITH week_entries AS (
                        SELECT 
                            strftime('%Y', datetime(start_time, 'unixepoch')) || '-W' || 
                            (CAST(strftime('%W', datetime(start_time, 'unixepoch')) AS INTEGER) + 1) AS week_str,
                            strftime('%Y-%m-%d', datetime(start_time, 'unixepoch')) AS week_start,
                            job.id AS job_id,
                            job.description AS job_description,
                            customer.name AS customer_name,
                            job.base_rate,
                            SUM((julianday(datetime(COALESCE(end_time, strftime('%s', 'now')), 'unixepoch')) - 
                                julianday(datetime(start_time, 'unixepoch'))) * 24) AS total_hours
                        FROM time_entry
                        JOIN job ON time_entry.job_id = job.id
                        JOIN customer ON job.customer_id = customer.id
                        GROUP BY week_str, job_id
                        ORDER BY week_str DESC, job_id
                    )
                    SELECT * FROM week_entries
                ''').fetchall()

                
                # Group by week
                weeks_summary = {}
                
                for entry in weekly_data:
                    week_str = entry['week_str']
                    
                    if week_str not in weeks_summary:
                        weeks_summary[week_str] = {
                            'week_start': entry['week_start'],
                            'job_totals': {},
                            'total_hours': 0,
                            'total_amount': 0
                        }
                    
                    # Create job key
                    job_key = f"{entry['job_id']}-{entry['job_description']}-{entry['customer_name']}"
                    
                    # Add job data
                    weeks_summary[week_str]['job_totals'][job_key] = {
                        'job_id': entry['job_id'],
                        'description': entry['job_description'],
                        'customer': entry['customer_name'],
                        'hours': entry['total_hours'],
                        'amount': entry['total_hours'] * (entry['base_rate'] or 0)
                    }
                    
                    # Update week totals
                    weeks_summary[week_str]['total_hours'] += entry['total_hours']
                    weeks_summary[week_str]['total_amount'] += entry['total_hours'] * (entry['base_rate'] or 0)
                
                # Sort weeks by most recent first
                sorted_weeks = sorted(weeks_summary.items(), key=lambda x: x[0], reverse=True)
                
                return render_template('weekly_summary.html',
                                    selected_week=selected_week,
                                    available_weeks=available_weeks,
                                    show_all=show_all,
                                    all_weeks=sorted_weeks)
            except Exception as e:
                logger.error(f"Error generating all weeks data: {str(e)}")
                return render_template('weekly_summary.html',
                                      selected_week=selected_week,
                                      available_weeks=available_weeks,
                                      show_all=False,
                                      error=f"Could not generate weekly summary: {str(e)}")
        
        # Process selected week
        try:
            if '-W' in selected_week:
                year, week_num = selected_week.split('-W')
                year = int(year)
                week_num = int(week_num)
                
                # Calculate start and end dates of the selected week
                start_date = date.fromisocalendar(year, week_num, 1)  # Monday
                end_date = date.fromisocalendar(year, week_num, 7)    # Sunday
            else:
                # Default to current week if format is invalid
                today = date.today()
                year, week_num, _ = today.isocalendar()
                start_date = date.fromisocalendar(year, week_num, 1)  # Monday
                end_date = date.fromisocalendar(year, week_num, 7)    # Sunday
                selected_week = f"{year}-W{week_num:02d}"
        except (ValueError, IndexError) as e:
            logger.error(f"Error parsing week format: {str(e)}")
            # Handle invalid week format
            return redirect(url_for('report.weekly_summary'))
        
        # Format for SQLite date comparison
        start_date_str = start_date.strftime('%Y-%m-%d')
        end_date_str = end_date.strftime('%Y-%m-%d')
        
        # Get all time entries for the selected week
        try:
            time_entries = db.execute('''
                SELECT 
                    time_entry.*,
                    job.description AS job_description,
                    job.base_rate,
                    customer.name AS customer_name,
                    (julianday(datetime(COALESCE(end_time, strftime('%s', 'now')), 'unixepoch')) - 
                    julianday(datetime(start_time, 'unixepoch'))) * 24 AS hours
                FROM time_entry
                JOIN job ON time_entry.job_id = job.id
                JOIN customer ON job.customer_id = customer.id
                WHERE date(datetime(start_time, 'unixepoch')) >= ? AND date(datetime(start_time, 'unixepoch')) <= ?
                ORDER BY start_time
            ''', (start_date_str, end_date_str)).fetchall()
        except Exception as e:
            logger.error(f"Error fetching time entries: {str(e)}")
            time_entries = []
        
        # Group by day and job
        days = {}
        job_totals = {}
        week_total_hours = 0
        week_total_amount = 0
        
        for entry in time_entries:
            try:
                entry_date = datetime.fromisoformat(entry['start_time']).date()
                day_str = entry_date.strftime('%Y-%m-%d')
                
                # Create a key for this job
                job_key = f"{entry['job_id']}-{entry['job_description']}-{entry['customer_name']}"
                
                # Initialize day if not exists
                if day_str not in days:
                    days[day_str] = {
                        'date': entry_date,
                        'day_name': entry_date.strftime('%A'),
                        'jobs': {},
                        'total_hours': 0,
                        'total_amount': 0
                    }
                
                # Initialize job for this day if not exists
                if job_key not in days[day_str]['jobs']:
                    days[day_str]['jobs'][job_key] = {
                        'job_id': entry['job_id'],
                        'description': entry['job_description'],
                        'customer': entry['customer_name'],
                        'entries': [],
                        'hours': 0,
                        'amount': 0
                    }
                
                # Add entry to the job for this day
                days[day_str]['jobs'][job_key]['entries'].append(entry)
                days[day_str]['jobs'][job_key]['hours'] += entry['hours']
                
                # Calculate amount if base_rate exists
                amount = 0
                if entry['base_rate']:
                    amount = entry['hours'] * entry['base_rate']
                    days[day_str]['jobs'][job_key]['amount'] += amount
                
                # Update day totals
                days[day_str]['total_hours'] += entry['hours']
                days[day_str]['total_amount'] += amount
                
                # Update week totals
                week_total_hours += entry['hours']
                week_total_amount += amount
                
                # Update job totals for the week
                if job_key not in job_totals:
                    job_totals[job_key] = {
                        'job_id': entry['job_id'],
                        'description': entry['job_description'],
                        'customer': entry['customer_name'],
                        'hours': 0,
                        'amount': 0
                    }
                job_totals[job_key]['hours'] += entry['hours']
                job_totals[job_key]['amount'] += amount
            except Exception as e:
                logger.error(f"Error processing entry {entry['id']}: {str(e)}")
                continue
        
        # Sort days chronologically
        sorted_days = sorted(days.items())
        
        return render_template('weekly_summary.html',
                              selected_week=selected_week,
                              available_weeks=available_weeks,
                              show_all=show_all,
                              days=sorted_days,
                              job_totals=job_totals,
                              week_total_hours=week_total_hours,
                              week_total_amount=week_total_amount,
                              start_date=start_date,
                              end_date=end_date)
    except Exception as e:
        logger.error(f"Unhandled exception in weekly_summary: {str(e)}", exc_info=True)
        return render_template('500.html', error=str(e))