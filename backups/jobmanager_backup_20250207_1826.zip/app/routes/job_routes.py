# app/routes/job_routes.py
from flask import Blueprint, render_template, request, redirect, url_for, jsonify
from ..utils.db_utils import with_db
from ..utils.job_utils import JobManager
from ..utils.material_utils import MaterialManager
from datetime import datetime

bp = Blueprint('job', __name__)

@bp.route('/')
@with_db
def job_list(db):
    jobs = db.execute('''
        WITH job_hours AS (
            SELECT 
                job_id,
                SUM((julianday(COALESCE(end_time, datetime('now'))) - julianday(start_time)) * 24) as hours
            FROM time_entry
            GROUP BY job_id
        )
        SELECT 
            job.*,
            customer.name as customer_name,
            te_active.id as active_timer_id,
            te_active.start_time as timer_start,
            COALESCE(job_hours.hours, 0) as accumulated_hours
        FROM job 
        JOIN customer ON job.customer_id = customer.id 
        LEFT JOIN time_entry te_active ON job.id = te_active.job_id 
            AND te_active.end_time IS NULL
        LEFT JOIN job_hours ON job_hours.job_id = job.id
        ORDER BY 
            te_active.id IS NOT NULL DESC,
            CASE job.status
                WHEN 'Active' THEN 1
                WHEN 'Pending' THEN 2
                WHEN 'Completed' THEN 3
            END,
            job.last_active DESC NULLS LAST,
            job.creation_date DESC
    ''').fetchall()
    return render_template('job_list.html', jobs=jobs)

@bp.route('/add/<int:customer_id>', methods=['GET', 'POST'])
@with_db
def add_job(db, customer_id):
    if request.method == 'POST':
        job_mgr = JobManager(db)
        job_mgr.create_job(customer_id, request.form)
        return redirect(url_for('job.job_list'))
        
    customer = db.execute('SELECT * FROM customer WHERE id = ?', 
                         [customer_id]).fetchone()
    return render_template('job_form.html', customer=customer)

@bp.route('/<int:id>/edit', methods=['GET', 'POST'])
@with_db
def edit_job(db, id):
    if request.method == 'POST':
        job_mgr = JobManager(db)
        job_mgr.update_job(id, request.form)
        return redirect(url_for('job.job_list'))
        
    job = db.execute('''
        SELECT job.*, customer.name as customer_name 
        FROM job JOIN customer ON job.customer_id = customer.id 
        WHERE job.id = ?''', [id]).fetchone()
    return render_template('job_form.html', job=job)

@bp.route('/<int:id>/delete', methods=['POST'])
@with_db
def delete_job(db, id):
    job_mgr = JobManager(db)
    job_mgr.delete_job(id)
    return redirect(url_for('job.job_list'))


@bp.route('/<int:id>/add_note', methods=['POST'])
@with_db
def add_note(db, id):
    note = request.form.get('note', '').strip()
    if note:
        now = datetime.now().isoformat()
        db.execute(
            'INSERT INTO job_note (job_id, note, timestamp) VALUES (?, ?, ?)',
            (id, note, now)
        )
        db.execute(
            'UPDATE job SET last_active = ? WHERE id = ?',
            (now, id)
        )
        db.commit()
        
    return jsonify({"success": True})

@bp.route('/details/<int:id>')
@with_db
def job_details(db, id):
    job = db.execute('''
        WITH job_hours AS (
            SELECT job_id,
                SUM((julianday(COALESCE(end_time, datetime('now'))) - julianday(start_time)) * 24) as hours
            FROM time_entry
            GROUP BY job_id
        )
        SELECT job.*, 
               customer.name as customer_name,
               COALESCE(job_hours.hours, 0) as accumulated_hours
        FROM job 
        JOIN customer ON job.customer_id = customer.id 
        LEFT JOIN job_hours ON job_hours.job_id = job.id
        WHERE job.id = ?
    ''', [id]).fetchone()
    
    time_entries = db.execute('''
        SELECT *, 
        (julianday(COALESCE(end_time, datetime('now'))) - julianday(start_time)) * 24 as hours
        FROM time_entry 
        WHERE job_id = ? 
        ORDER BY start_time DESC
    ''', [id]).fetchall()
    
    total_hours = sum(entry['hours'] for entry in time_entries)
    total_amount = total_hours * (job['base_rate'] or 0)
    
    materials = db.execute('''
        SELECT * FROM job_material 
        WHERE job_id = ? 
        ORDER BY timestamp DESC
    ''', [id]).fetchall()
    
    notes = db.execute('''
        SELECT * FROM job_note 
        WHERE job_id = ? 
        ORDER BY timestamp DESC
    ''', [id]).fetchall()
    
    return render_template('job_details.html', 
                         job=job, 
                         time_entries=time_entries,
                         materials=materials,
                         notes=notes,
                         total_hours=total_hours,
                         total_amount=total_amount)
    
    

    db.execute('DELETE FROM time_entry WHERE id = ? AND job_id = ?', 
               [entry_id, job_id])
    db.commit()
    return redirect(url_for('job.job_details', id=job_id))

@bp.route('/<int:job_id>/edit_time_entry/<int:entry_id>', methods=['POST'])
@with_db
def edit_time_entry(db, job_id, entry_id):
    db.execute('''
        UPDATE time_entry 
        SET start_time = ?, end_time = ? 
        WHERE id = ? AND job_id = ?
    ''', [request.form['start_time'], request.form['end_time'], 
          entry_id, job_id])
    db.commit()
    return redirect(url_for('job.job_details', id=job_id))

@bp.route('/<int:id>/add_material', methods=['POST'])
@with_db
def add_material(db, id):
    material = request.form.get('material', '').strip()
    quantity = request.form.get('quantity', 0, type=float)
    price = request.form.get('price', 0, type=float)
    
    if material:
        material_mgr = MaterialManager(db)
        material_mgr.add_material(id, {
            'material': material,
            'quantity': quantity,
            'price': price
        })
    return redirect(url_for('job.job_details', id=id))

@bp.route('/<int:id>/delete_material/<int:material_id>', methods=['POST'])
@with_db
def delete_material(db, id, material_id):
    db.execute('DELETE FROM job_material WHERE id = ? AND job_id = ?', 
               [material_id, id])
    db.commit()
    return redirect(url_for('job.job_details', id=id))

@bp.route('/<int:id>/edit_material/<int:material_id>', methods=['POST'])
@with_db
def edit_material(db, id, material_id):
    db.execute('''
        UPDATE job_material 
        SET material = ?, quantity = ?, price = ?
        WHERE id = ? AND job_id = ?
    ''', [request.form['material'], request.form['quantity'], 
          request.form['price'], material_id, id])
    db.commit()
    return redirect(url_for('job.job_details', id=id))

@bp.route('/<int:id>/delete_time_entry/<int:entry_id>', methods=['POST'])
@with_db
def delete_time_entry(db, id, entry_id):
    db.execute('DELETE FROM time_entry WHERE id = ? AND job_id = ?', 
               [entry_id, id])
    db.commit()
    return redirect(url_for('job.job_details', id=id))