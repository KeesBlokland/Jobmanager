# utils/time_utils.py
import time
from datetime import datetime, timezone

def get_current_time():
    """Get current time in seconds since epoch."""
    return int(time.time())

def format_time(timestamp, format_str='%Y-%m-%d %H:%M:%S'):
    """Format timestamp as string using specified format."""
    if timestamp is None:
        return ""
    return datetime.fromtimestamp(timestamp).strftime(format_str)

def format_duration(seconds):
    """Format duration in seconds to human-readable format."""
    if seconds is None or seconds < 0:
        return "00:00:00"
    
    hours, remainder = divmod(seconds, 3600)
    minutes, seconds = divmod(remainder, 60)
    return f"{int(hours):02d}:{int(minutes):02d}:{int(seconds):02d}"

def parse_time(time_str, format_str='%Y-%m-%d %H:%M:%S'):
    """Parse time string to timestamp."""
    if not time_str:
        return None
    dt = datetime.strptime(time_str, format_str)
    # Ensure timestamp is created in local timezone context
    return int(dt.timestamp())